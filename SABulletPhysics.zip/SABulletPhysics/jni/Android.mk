LOCAL_PATH := $(call my-dir)
include $(CLEAR_VARS)
LOCAL_MODULE    := BulletPhysics64
LOCAL_SRC_FILES := ../main.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)/..          # folder yang berisi mod/amlmod.h (dari repo AndroidModLoader)
LOCAL_CPPFLAGS  := -O2 -std=c++17 -fvisibility=hidden -DNDEBUG
LOCAL_LDLIBS    := -llog -ldl
include $(BUILD_SHARED_LIBRARY)
