# SA Bullet Physics (AML 64-bit)

Fitur: bullet drop, ricochet (peluru mantul) kecil kemungkinannya, tracer melengkung lewat libBulletTracers64.so.

## Build
1. GitHub: buat repo, upload isi folder ini, buka tab Actions -> build -> unduh `libBulletPhysics64.so`.
   (Atau lokal: salin folder `mod/` dari github.com/RusJJ/AndroidModLoader ke sini, lalu `ndk-build`.)
2. Taruh `libBulletPhysics64.so` di folder mod AML (sebelah libBulletTracers64.so).
3. Taruh `BulletPhysics.ini` di folder configs AML.

## Cara kerja
- `CWeapon::FireInstantHit` ditandai sebagai "sedang menembak".
- Selama itu, `CWorld::ProcessLineOfSight` dibengkokkan jadi lintasan parabola (dipotong beberapa segmen). Hasil kena/tidaknya, damage, efek impact tetap diurus game.
- Ricochet: di titik kena, kalau surface cocok (besi/kendaraan/jalan) dan lolos persentase, dihitung arah pantul. Lintasan pantul digambar tracer. Tidak ada damage dari pantulan.
- Tracer: garis lurus bawaan game diblok (hook AddTrace1/AddTrace2 di libGTASA), lalu segmen lengkung dikirim langsung ke fungsi export libBulletTracers64.so, jadi warna/gaya tracer-mu tetap dipakai.

## Kalau tidak jalan
- Lihat logcat tag `SABulletPhysics`. Kalau "symbol tidak ketemu", cari offset FireInstantHit & ProcessLineOfSight di libGTASA.so lalu isi di `[Addresses]`.
- Set `LogShots=1` untuk lihat berapa trace bawaan yang berhasil diblok. Kalau garis lurus masih muncul, ada jalur tracer lain yang belum diblok.
- Set `LogSurface=1` untuk melihat ID surface yang kena tembak dan sesuaikan daftar ricochet.
